<?php 
include ('include/header.php');
$metakey=$db->prepare("SELECT * from meta where meta_id=2");
$metakey->execute(array(0));
$metakeyprint=$metakey->fetch(PDO::FETCH_ASSOC);
?>
<title><?php echo $metakeyprint['meta_title'] ?></title>
<meta name="description" content="<?php echo $metakeyprint['meta_descr'] ?>">
<meta name="keywords" content="<?php echo $metakeyprint['meta_keyword'] ?>">
<?php
include ('include/menu.php');
?>
<div class="main-content">
  <section class="inner-header parallax layer-overlay overlay-dark-7" data-bg-img="trex/<?php echo $settingsprint['ayar_resimcounter']; ?>">
    <div class="container pt-70 pb-70">
      <div class="section-content">
        <div class="row"> 
          <div class="col-sm-8 xs-text-center">
            <h2 class="text-white mt-10">Hizmetlerimiz</h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container mt-30 mb-30 pt-30 pb-30">
      <div class="row">
        <div class="col-md-12 blog-pull-right">
         <?php 
         $hizmetsor=$db->prepare("SELECT * from hizmetler order by hizmet_id DESC");
         $hizmetsor->execute(array(0));
         while ($hizmetcek=$hizmetsor->fetch(PDO::FETCH_ASSOC)) {
          ?>
          <div class="col-md-4">
            <div class="item">
              <div class="project mb-30">
                <div class="thumb">
                  <img style="height: 200px" class="img-fullwidth" alt="<?php echo $hizmetcek['hizmet_baslik']; ?>" src="trex/<?php echo $hizmetcek['hizmet_resim']; ?>">
                  <div class="hover-link">
                    <a href="<?=seo('hizmet-'.$hizmetcek["hizmet_baslik"]).'-'.$hizmetcek["hizmet_id"]?>"><i class="flaticon-attachment"></i></a>
                  </div>
                </div>
                <div class="project-details p-15 pt-10 pb-10">
                  <h4 class="title font-weight-700 mt-0"><?php echo mb_substr($hizmetcek['hizmet_baslik'], 0 , 55 , "UTF-8"); ?></h4>
                </div>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
</section>
</div>
<?php include ('include/footer.php'); ?>
