<?php
include '../trex/controller/config.php';
include '../trex/controller/seo.php';

if ( isset( $_POST[ 'city_id' ] ) )
{
	$getCityID = $_POST[ 'city_id' ];
	$ilcesor   = $db->prepare( "SELECT * from ilce where il_id=$getCityID order by id" );
	$ilcesor->execute( array( 0 ) );
    ?><option value="">İlçe seçiniz.</option> <?php
    while ($ilcecek=$ilcesor->fetch(PDO::FETCH_ASSOC)) {
      ?>
      <option value="<?php echo $ilcecek['ilce_adi'] ?>"><?php echo $ilcecek['ilce_adi'] ?></option>

  <?php }
}
