<?php 
include ('include/header.php');
$projeedit=$db->prepare("SELECT * from projeler where proje_id=:proje_id");
$projeedit->execute(array(
  'proje_id' => $_GET['proje_id']
));
$projewrite=$projeedit->fetch(PDO::FETCH_ASSOC);
?>
<title><?php echo $projewrite['proje_title'] ?></title>
<meta name="description" content="<?php echo $projewrite['proje_descr'] ?>">
<meta name="keywords" content="<?php echo $projewrite['proje_keyword'] ?>">
</head>
<?php
include ('include/menu.php');
?>
<div class="main-content">
  <section class="inner-header parallax layer-overlay overlay-dark-7" data-bg-img="trex/<?php echo $settingsprint['ayar_resimcounter']; ?>">
    <div class="container pt-70 pb-70">
      <div class="section-content">
        <div class="row"> 
          <div class="col-sm-8 xs-text-center">
            <h2 class="text-white mt-10"><?php echo $projewrite['proje_baslik']; ?></h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container mt-30 mb-30 pt-30 pb-30">
      <div class="row">
        <div class="col-md-8 blog-pull-right">
          <div class="single-service">
            <h4 class="mt-0 mb-20"><?php echo $projewrite['proje_baslik']; ?></h4>
            <img style="width: 100%;" src="trex/<?php echo $projewrite['proje_resim']; ?>" class="img-responsive" alt="<?php echo $projewrite['proje_baslik']; ?>" />
            <p><?php echo $projewrite['proje_icerik']; ?></p>
          </div>
        </div>
        <?php include ('include/sidebar.php'); ?>
      </div>
    </div>
  </section>
</div>
<?php include ('include/footer.php'); ?>
