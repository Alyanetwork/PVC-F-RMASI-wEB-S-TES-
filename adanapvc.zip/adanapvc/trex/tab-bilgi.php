<?php 
include 'header.php';
include 'topbar.php';
include 'sidebar.php';
$slaytsor=$db->prepare("SELECT * from tabbilgi order by tabbilgi_id DESC");
$slaytsor->execute(array(0));
?>		
<!-- ============================================================== -->
<!-- 						Content Start	 						-->
<!-- ============================================================== -->
<section class="main-content container">
	<div class="page-header">
		<h2>Tab Bilgi İşlemleri</h2>
	</div>
	<div class="row">
		<!-- İLETİŞİM MESAJLARI -->
		<div class="col-md-12">
			<div class="card">
				<div class="card-heading card-default">
					Tab Bilgi
				</div>
				<div class="card-block">
					<table id="datatable1" class="table table-striped dt-responsive nowrap table-hover">
						<thead>
							<tr>
								<th class="text-left">
									<strong>Tab Bilgi Sıra</strong>
								</th>
								<th class="text-left">
									<strong>Tab Bilgi Resim</strong>
								</th>
								<th class="text-left">
									<strong>Tab Bilgi Başlık</strong>
								</th>
								<th class="text-left">
									<strong>Tab Bilgi aciklama</strong>
								</th>
								<th class="text-center">
									<strong>İşlemler</strong>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							while ($slaytcek=$slaytsor->fetch(PDO::FETCH_ASSOC)) {
								?>
								<tr>
									<td><?php echo $slaytcek['tabbilgi_sira']; ?></td>
									<td><img style="max-height: 150px;max-width: 150px;" src="<?php echo $slaytcek['tabbilgi_resim']; ?>"></td>
									<td><?php echo $slaytcek['tabbilgi_baslik']; ?></td>
									<td><?php echo mb_substr(strip_tags($slaytcek['tabbilgi_aciklama']), 0, 80, "UTF-8"); ?></td>
									<td class="text-center">
										<a href="tabbilgi-duzenle.php?tabbilgi_id=<?php echo $slaytcek['tabbilgi_id']; ?>" title="Düzenle" class="btn btn-sm btn-success"><i class="fa fa-edit"></i></a>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<!-- İLETİŞİM MESAJLARI -->
	</div>

	<?php include 'footer.php'; ?>
