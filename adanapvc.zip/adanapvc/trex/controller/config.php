<?php

try {

	$db=new PDO("mysql:host=localhost;dbname=alyabili_pvcadana",'alyabili_pvcadana',']s-tS_iUUA' );
	$db->query("SET CHARACTER SET utf8");
	//echo "veritabanı bağlantısı başarılı";

}

catch (PDOExpception $e) {

	echo $e->getMessage();
}
