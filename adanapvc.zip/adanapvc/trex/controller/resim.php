<?php 

ob_start();

session_start();

include 'config.php';
include 'seo.php';


if (!empty($_FILES)) {

	$urunedit=$db->prepare("SELECT * from tur where tur_id=:tur_id");
	$urunedit->execute(array(
		'tur_id' => $_POST['tur_resim']
	));
	$urunwrite=$urunedit->fetch(PDO::FETCH_ASSOC);

	$resimsor=$db->prepare("SELECT * from turresim where turresim_tur=:resim_urun");
	$resimsor->execute(array(
		'resim_urun' => $_POST['tur_resim']

	));
	$resimcek=$resimsor->fetch(PDO::FETCH_ASSOC);

	$resimsay=$resimsor->Rowcount();



	if ($resimsay<=50) {



		$uploads_dir = '../assets/img/turlar';

		@$tmp_name = $_FILES['file']["tmp_name"];

		$benzersizsayi1=rand(20000,32000);

		$benzersizsayi2=rand(20000,32000);

		$uzanti = '.jpg';

		$baslik = seo($urunwrite['tur_baslik']);

		$benzersizad=$benzersizsayi1."-".$benzersizsayi2."-".$baslik;

		$refimgyol=substr($uploads_dir, 3)."/".$benzersizad.$uzanti;

		@move_uploaded_file($tmp_name, "$uploads_dir/$benzersizad$uzanti");



		$kaydet=$db->prepare("INSERT INTO turresim SET
			turresim_tur=:urun,
			turresim_link=:rs
			");
		$insert=$kaydet->execute(array(
			'urun' => $_POST['tur_resim'],
			'rs' => $refimgyol

		));



	} else {
		echo "resim limitini aştınız";
	}


}


?>
