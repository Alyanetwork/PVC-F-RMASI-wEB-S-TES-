<?php 
include ('include/header.php');
$metakey=$db->prepare("SELECT * from meta where meta_id=9");
$metakey->execute(array(0));
$metakeyprint=$metakey->fetch(PDO::FETCH_ASSOC);
?>
<title><?php echo $metakeyprint['meta_title'] ?></title>
<meta name="description" content="<?php echo $metakeyprint['meta_descr'] ?>">
<meta name="keywords" content="<?php echo $metakeyprint['meta_keyword'] ?>">
<?php
include ('include/menu.php');
?>
<div class="main-content">
  <section class="inner-header parallax layer-overlay overlay-dark-7" data-bg-img="trex/<?php echo $settingsprint['ayar_resimyorumg']; ?>">
    <div class="container pt-70 pb-70">
      <div class="section-content">
        <div class="row"> 
          <div class="col-sm-8 xs-text-center">
            <h2 class="text-white mt-10">Randevu Al</h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="divider bg-lighter">
    <div class="container">
      <div class="row pt-0">
        <div class="col-md-12">
          <form action="trex/controller/function.php" method="POST" class="mt-30">
            <h3>Randevu Alın</h3>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label class="">Ad ve Soyadınız</label>
                  <input name="randevu_ad" type="text" class="form-control" required="" placeholder="Adınız Soyadınız">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label class="">Telefon Numaranız</label>
                  <input name="randevu_tel" type="text" class="form-control" required="" placeholder="Telefon Numaranız">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label class="">Mail Adresiniz</label>
                  <input name="randevu_mail" type="email" class="form-control" required="" placeholder="Mail adresiniz">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label class="">Tarih Seçin</label>
                  <input name="randevu_zaman" type="date" class="form-control">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <label>Hizmet Seçin</label>
                  <select name="randevu_hizmet" class="form-control" required="">
                    <?php 
                    $hizmetarticle=$db->prepare("SELECT * from hizmetler order by hizmet_id DESC");
                    $hizmetarticle->execute(array(0));

                    while ($hizmetarticleprint=$hizmetarticle->fetch(PDO::FETCH_ASSOC)) { 
                      ?>
                      <option value="<?php echo $hizmetarticleprint['hizmet_baslik'] ?>"><?php echo $hizmetarticleprint['hizmet_baslik'] ?></option>
                    <?php } ?>
                    <option value="Diğer">Diğer (Detayları not kısmında belirtiniz.)</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label class="">İl Seçin</label>
                  <select name="randevu_il" id="il" class="form-control" required="">
                   <option value="" disabled selected>İl Seçiniz</option>
                   <?php
                   $ilsor=$db->prepare("SELECT * from il order by id ASC");
                   $ilsor->execute(array(0));
                   while ($ilcek=$ilsor->fetch(PDO::FETCH_ASSOC)) {?>
                     <option data-id="<?php echo $ilcek['il_plaka'] ?>" value="<?php echo $ilcek['il_adi'] ?>"><?php echo $ilcek['il_adi'] ?></option>
                   <?php } ?>
                   <option value="Diğer">Diğer (Detayları not kısmında belirtiniz.)</option>
                 </select>
               </div>
             </div>
             <div class="col-md-6">
              <div class="form-group">
                <label>İlçe Seçin</label>
                <select id="getIlceForIl" name="ilan_ilce" class="getIlceForIl radio-dropdown form-control" style="width: 100%;padding: 7px;">
                 <option value="">Önce il seçiniz</option>
               </select>
             </div></div>
           </div>


           <div class="form-group">
            <label>Adresiniz</label>
            <textarea name="randevu_not" rows="5" class="form-control" placeholder="Açık Adresiniz."></textarea>
          </div>
          <button name="randevu" type="submit" class="btn btn-dark btn-theme-colored btn-flat" style="cursor: pointer;">Gönder</button>
        </form>
      </div>
    </div>
  </div>
</section>
</div>
<?php include ('include/footer.php'); ?>
