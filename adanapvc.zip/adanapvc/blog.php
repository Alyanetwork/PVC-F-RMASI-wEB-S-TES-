<?php 
include ('include/header.php');
$metakey=$db->prepare("SELECT * from meta where meta_id=4");
$metakey->execute(array(0));
$metakeyprint=$metakey->fetch(PDO::FETCH_ASSOC);
?>
<title><?php echo $metakeyprint['meta_title'] ?></title>
<meta name="description" content="<?php echo $metakeyprint['meta_descr'] ?>">
<meta name="keywords" content="<?php echo $metakeyprint['meta_keyword'] ?>">
<?php
include ('include/menu.php');

$sayfada = 6; // sayfada gösterilecek içerik miktarını belirtiyoruz.
$sorgu=$db->prepare("SELECT * from blog");
$sorgu->execute();
$toplam_icerik=$sorgu->rowCount();
$toplam_sayfa = ceil($toplam_icerik / $sayfada);
                  // eğer sayfa girilmemişse 1 varsayalım.
$sayfa = isset($_GET['sayfa']) ? (int) $_GET['sayfa'] : 1;
                // eğer 1'den küçük bir sayfa sayısı girildiyse 1 yapalım.
if($sayfa < 1) $sayfa = 1; 
                // toplam sayfa sayımızdan fazla yazılırsa en son sayfayı varsayalım.
if($sayfa > $toplam_sayfa) $sayfa = $toplam_sayfa; 
$limit = ($sayfa - 1) * $sayfada;
$blogsor1=$db->prepare("SELECT * from blog order by blog_tarih DESC limit $limit,$sayfada");
$blogsor1->execute();

?>
<div class="main-content">
  <section class="inner-header parallax layer-overlay overlay-dark-7" data-bg-img="trex/<?php echo $settingsprint['ayar_resimyorumg']; ?>">
    <div class="container pt-70 pb-70">
      <div class="section-content">
        <div class="row"> 
          <div class="col-sm-8 xs-text-center">
            <h2 class="text-white mt-10">Blog</h2>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="container mt-30 mb-30 pt-30 pb-30">
      <div class="row">
        <div class="col-md-8 blog-pull-right">







          <?php 
          while ($blogcek=$blogsor1->fetch(PDO::FETCH_ASSOC)) {
            $blogicerik=mb_substr(strip_tags($blogcek['blog_detay']), 0, 70, 'UTF-8')."...";
            ?>



            <div class="col-md-6">
              <article class="post clearfix mb-30 bg-lighter">
                <div class="entry-header">
                  <div class="post-thumb thumb"> 
                    <img src="trex/<?php echo $blogcek['blog_resim']; ?>" alt="<?php echo $blogcek['blog_baslik']; ?>" class="img-responsive img-fullwidth">
                  </div>
                </div>
                <div class="entry-content p-20">
                  <h4 class="entry-title text-white"><a class="font-weight-600" href="<?=seo('blog-'.$blogcek["blog_baslik"]).'-'.$blogcek["blog_id"]?>"><?php echo mb_substr($blogcek['blog_baslik'], 0,25,"UTF-8"); ?></a></h4>
                  <p class="mt-5"><?php echo mb_substr($blogcek['blog_detay'], 0,100,"UTF-8"); ?></p>
                  <a class="btn btn-theme-colored btn-sm mt-10" href="<?=seo('blog-'.$blogcek["blog_baslik"]).'-'.$blogcek["blog_id"]?>">Detaylar</a>
                </div>
              </article>
            </div>

          <?php } ?>





          <div class="col-md-12 text-center">


            <nav>
              <ul class="pagination theme-colored">
                      <?php $gosterilecekbuton = 3; // gösterilecek sayfa.
                      if ($sayfa > 1) {
                        ?>
                        <li class="page-item">
                          <a class="page-link" href="?=sayfa=1"><i class="fa fa-angle-double-left"></i></a>
                          <a class="page-link" href="?sayfa=<?php echo $sayfa-1; ?>"><i class="fa fa-angle-left"></i></a>
                        </li>
                      <?php }
                      for ($i= $sayfa - $gosterilecekbuton; $i < $sayfa + $gosterilecekbuton +1; $i++) {
                        if ($i > 0 and $i <= $toplam_sayfa) {
                          if ($i == $sayfa) {
                            ?>
                            <li class="page-item active">
                              <a class="page-link" href="?sayfa=<?php echo $i ?>"><?php echo $i ?> <span class="sr-only">(current)</span></a>
                            </li>
                            <?php
                          } else {
                            ?>
                            <li class="page-item">
                              <a class="page-link" href="?sayfa=<?php echo $i ?>"><?php echo $i ?> <span class="sr-only">(current)</span></a>
                            </li>
                            <?php
                          }
                        }
                      }
                      if ($sayfa != $toplam_sayfa) {
                        ?>
                        <li class="page-item">
                          <a class="page-link" href="?sayfa=<?php echo $sayfa+1; ?>"><i class="fa fa-angle-right"></i></a>
                          <a class="page-link" href="?sayfa=<?php echo $toplam_sayfa; ?>"><i class="fa fa-angle-double-right"></i></a>
                        </li>
                      <?php } ?>

                    </ul>
                  </nav>










                </div>


              </div>
              <?php include ('include/sidebar.php'); ?>
            </div>
          </div>
        </section>
      </div>
      <?php include ('include/footer.php'); ?>
