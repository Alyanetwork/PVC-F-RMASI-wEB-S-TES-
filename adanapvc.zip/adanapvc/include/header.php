<?php
include 'trex/controller/config.php'; 
include 'trex/controller/seo.php';
date_default_timezone_set('Europe/Istanbul');
$settings=$db->prepare("SELECT * from ayar where ayar_id=?");
$settings->execute(array(0));
$settingsprint=$settings->fetch(PDO::FETCH_ASSOC);

$social=$db->prepare("SELECT * from sosyal");
$social->execute();

$socialf=$db->prepare("SELECT * from sosyal");
$socialf->execute();

$socials=$db->prepare("SELECT * from sosyal");
$socials->execute();

$motor=$db->prepare("SELECT * from motor where motor_id=1");
$motor->execute(array(0));
$motorprint=$motor->fetch(PDO::FETCH_ASSOC);

$widgets=$db->prepare("SELECT * from widget where widget_id=1");
$widgets->execute(array(0));
$widgetprint=$widgets->fetch(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html dir="ltr" lang="tr">
<head>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
  <meta name="author" content=""/>
  <link  href="css/jquery.fancybox.css" rel="stylesheet">
  <link rel="shortcut icon" href="trex/<?php echo $settingsprint['ayar_fav']; ?>"/>
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/jquery-ui.min.css" rel="stylesheet" type="text/css">
  <link href="css/animate.css" rel="stylesheet" type="text/css">
  <link href="css/css-plugin-collections.css" rel="stylesheet"/>
  <link id="menuzord-menu-skins" href="css/menuzord-skins/menuzord-rounded-boxed.css" rel="stylesheet"/>
  <link href="css/style-main.css" rel="stylesheet" type="text/css">
  <link href="css/preloader.css" rel="stylesheet" type="text/css">
  <link href="css/custom-bootstrap-margin-padding.css" rel="stylesheet" type="text/css">
  <link href="css/responsive.css" rel="stylesheet" type="text/css">
  <link href="css/colors/theme-skin-sky-blue-light.css" rel="stylesheet" type="text/css">
  <link href="js/revolution-slider/css/settings.css" rel="stylesheet" type="text/css"/>
  <link href="js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css"/>
  <link href="js/revolution-slider/css/navigation.css" rel="stylesheet" type="text/css"/>
  <script src="js/jquery-2.2.4.min.js"></script>
  <script src="js/main.js"></script>
  <script src="js/jquery-ui.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery-plugin-collection.js"></script>
  <script src="js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
  <script src="js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>
  <link href="trex/assets/lib/sweet-alerts2/sweetalert2.min.css" rel="stylesheet">
  <?php 
  echo $motorprint['motor_yonay']; 
  echo $motorprint['motor_gonay']; 
  ?>

